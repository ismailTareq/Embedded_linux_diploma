#include "rclcpp/rclcpp.hpp"
#include "turtlesim/srv/spawn.hpp"
#include "turtlesim/srv/kill.hpp"
#include "comm_msg/msg/turtle.hpp"
#include "comm_msg/msg/array.hpp"
#include "comm_msg/srv/catch_turtle.hpp"
#include <cmath>
#include <chrono>
#include <iostream>
#include <cstdlib>  
#include <vector>   

using namespace std::chrono_literals;
using namespace std::placeholders;

class TurtleSpawn : public rclcpp::Node
{
private:
    std::string name;
    std::string kill_turtle;
    int count;
    comm_msg::msg::Turtle turtle_saved;
    std::vector<comm_msg::msg::Turtle> alive_turtles;

    rclcpp::Client<turtlesim::srv::Spawn>::SharedPtr client_;
    rclcpp::Client<turtlesim::srv::Kill>::SharedPtr kill_client;
    rclcpp::Service<comm_msg::srv::CatchTurtle>::SharedPtr catch_service;  // Fixed service declaration
    rclcpp::Publisher<comm_msg::msg::Array>::SharedPtr pub;
    rclcpp::TimerBase::SharedPtr timer_;
    
public:
    TurtleSpawn() : Node("turtle_spawner"), count(0)
    {
        name = "turtle";
        client_ = this->create_client<turtlesim::srv::Spawn>("/spawn");
        kill_client = this->create_client<turtlesim::srv::Kill>("/kill");
        catch_service = this->create_service<comm_msg::srv::CatchTurtle>(
            "/catch_the_bitch",
            std::bind(&TurtleSpawn::catchcallback, this, _1, _2)
        );
        pub = this->create_publisher<comm_msg::msg::Array>("/new_bitch", 10);

        timer_ = this->create_wall_timer(
            3000ms, std::bind(&TurtleSpawn::spawn_newturtle, this)
        );
    }
    
    double random_position()
    {
        return static_cast<double>(std::rand()) / (static_cast<double>(RAND_MAX) + 1.0); 
    }

    void spawn_newturtle()
    {
        count++;
        if(count == 1)
            count++;
        auto name_prefix = name + std::to_string(count);
        double x = random_position() * 10.0;
        double y = random_position() * 10.0;
        double theta = random_position() * 2 * M_PI;
        turtle_service(name_prefix, x, y, theta);
    }
    
    void turtle_service(std::string n, double x, double y, double theta)
    {
        while(!client_->wait_for_service(1s))
        {
            RCLCPP_INFO(this->get_logger(), "waiting for service.....");
            if (!rclcpp::ok()) {
                RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for service.");
                return;
            }
        }
        auto request = std::make_shared<turtlesim::srv::Spawn::Request>();
        request->name = n;
        request->x = x;
        request->y = y;
        request->theta = theta;
        
        turtle_saved = comm_msg::msg::Turtle();
        turtle_saved.name = n;
        turtle_saved.x = x;
        turtle_saved.y = y;
        turtle_saved.theta = theta;
        
        client_->async_send_request(request, std::bind(&TurtleSpawn::callback, this, _1));
    }
    
    void callback(rclcpp::Client<turtlesim::srv::Spawn>::SharedFuture res)
    {
        auto response = res.get();
        if(response->name != "")
        {
            RCLCPP_INFO(this->get_logger(), "turtle %s is alive kill it", response->name.c_str());
            auto new_bitch = comm_msg::msg::Turtle();
            new_bitch.name = turtle_saved.name;
            new_bitch.x = turtle_saved.x;
            new_bitch.y = turtle_saved.y;
            new_bitch.theta = turtle_saved.theta;
            alive_turtles.push_back(new_bitch);
            publishnewbitch();
        }
    }
    
    void catchcallback(const comm_msg::srv::CatchTurtle::Request::SharedPtr req,
                       const comm_msg::srv::CatchTurtle::Response::SharedPtr res)
    {
        killturtleservice(req->name);
        res->success = true;
    }
    
    void killturtleservice(std::string name)
    {
        while(!kill_client->wait_for_service(1s))
        {
            RCLCPP_INFO(this->get_logger(), "Waiting for turtlesim to be ready...");
            if (!rclcpp::ok()) {
                RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for service.");
                return;
            }
        }
        auto req = std::make_shared<turtlesim::srv::Kill::Request>();
        req->name = name;
        kill_turtle = name;
        kill_client->async_send_request(req, std::bind(&TurtleSpawn::anothercallback, this, _1));
    }
    
    void anothercallback(rclcpp::Client<turtlesim::srv::Kill>::SharedFuture future)
    {
            (void)future.get();  // Check if the service call was successful
            for (int i = 0; i < int(alive_turtles.size()); i++)  // Changed int to size_t
            {
                if(alive_turtles.at(i).name == kill_turtle)
                {
                    alive_turtles.erase(alive_turtles.begin() + i);
                    publishnewbitch();
                    break;  // Added break to avoid invalid iterator after erase
                }
            }

    }
    
    void publishnewbitch()
    {
        auto msg = comm_msg::msg::Array();
        msg.turtles = alive_turtles;
        pub->publish(msg);
    }
};

int main(int argc, char** argv)  // Fixed main function signature
{
    rclcpp::init(argc, argv);  // Fixed initialization
    auto node = std::make_shared<TurtleSpawn>();
    rclcpp::spin(node);
    rclcpp::shutdown();

    return 0;
}