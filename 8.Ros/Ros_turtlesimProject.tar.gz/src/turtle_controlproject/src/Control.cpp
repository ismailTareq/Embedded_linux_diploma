#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "turtlesim/msg/pose.hpp"
#include "comm_msg/msg/turtle.hpp"
#include "comm_msg/msg/array.hpp"
#include "comm_msg/srv/catch_turtle.hpp"
#include <cmath>
#include <chrono>
#include <iostream>

using namespace std::chrono_literals;
using namespace std::placeholders;

class TurtleController : public rclcpp::Node
{
private:
    double target_x;
    double target_y;
    std::string name;
    bool turtlesim_ready;
    comm_msg::msg::Turtle catch_turtle;
    turtlesim::msg::Pose current_pose;
    bool closest_turtle;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr subscription_;
    rclcpp::Subscription<comm_msg::msg::Array>::SharedPtr sub_turtle;
    rclcpp::Client<comm_msg::srv::CatchTurtle>::SharedPtr catch_turtleClient;
    rclcpp::TimerBase::SharedPtr timer_;
    
public:
    TurtleController() : Node("turtle_controller"), name("turtle1"), turtlesim_ready(false)
    {
        this->declare_parameter("closest_turtle",true);
        closest_turtle = this->get_parameter("closest_turtle").as_bool();
        subscription_ = this->create_subscription<turtlesim::msg::Pose>(
            name + "/pose", 10, std::bind(&TurtleController::pose_callback, this, _1)
        );
        publisher_ = this->create_publisher<geometry_msgs::msg::Twist>(name + "/cmd_vel", 10);
        timer_ = this->create_wall_timer(
            100ms, std::bind(&TurtleController::control_loop, this)
        );
        sub_turtle = this->create_subscription<comm_msg::msg::Array>(
            "/new_bitch", 10, std::bind(&TurtleController::turtle_callback, this, _1)
        );
        catch_turtleClient = this->create_client<comm_msg::srv::CatchTurtle>("/catch_the_bitch");
        
        // Initialize catch_turtle with empty name
        catch_turtle.name = "";
    }
    
    void pose_callback(const turtlesim::msg::Pose::SharedPtr msg)
    {
        current_pose = *msg;
        turtlesim_ready = true;
    }

    void turtle_callback(const comm_msg::msg::Array::SharedPtr msg)
    {
        if(!msg->turtles.empty())
        {
            catch_turtle = msg->turtles.at(0);
        }
    }

    void control_loop()
    {
        if (!turtlesim_ready || catch_turtle.name == "")
        {
            RCLCPP_INFO(this->get_logger(), "Waiting for turtlesim to be ready...");
            return;
        }
        
        double x = catch_turtle.x - current_pose.x;
        double y = catch_turtle.y - current_pose.y;
        double distance = std::sqrt(x * x + y * y);

        auto msg = geometry_msgs::msg::Twist();

        if (distance > 0.5)
        {
            // Limit linear velocity for smoother movement
            msg.linear.x = std::min(distance, 2.0);
            
            double angle_to_target = std::atan2(y, x);
            double angle_diff = angle_to_target - current_pose.theta;
            
            // Normalize angle difference to [-π, π]
            if (angle_diff > M_PI)
                angle_diff -= 2 * M_PI;
            else if (angle_diff < -M_PI)
                angle_diff += 2 * M_PI;
                
            // Limit angular velocity
            msg.angular.z = std::min(6.0 * angle_diff, 2.0);
        }
        else
        {
            msg.linear.x = 0.0;
            msg.angular.z = 0.0;
            callcatchturtleservice(catch_turtle.name);
            RCLCPP_INFO(this->get_logger(), "Target reached.");
            catch_turtle.name = "";
        }
        publisher_->publish(msg);
    }    
    
    void callcatchturtleservice(std::string turtle_name)
    {
        while (!catch_turtleClient->wait_for_service(1s))
        {
            RCLCPP_INFO(this->get_logger(), "Waiting for service to be ready...");
            if (!rclcpp::ok()) {
                RCLCPP_ERROR(this->get_logger(), "Interrupted while waiting for service.");
                return;
            }
        }
        
        auto req = std::make_shared<comm_msg::srv::CatchTurtle::Request>();
        req->name = turtle_name;
        
        catch_turtleClient->async_send_request(req, 
            std::bind(&TurtleController::catchturtlecallback, this, _1));
    }
    
    void catchturtlecallback(rclcpp::Client<comm_msg::srv::CatchTurtle>::SharedFuture future)
    {
        try {
            auto response = future.get();
            if(!response->success)
            {
                RCLCPP_ERROR(this->get_logger(), "Failed to catch turtle: %s", catch_turtle.name.c_str());
            }
            else
            {
                RCLCPP_INFO(this->get_logger(), "Successfully caught turtle: %s", catch_turtle.name.c_str());
            }
        } catch (const std::exception &e) {
            RCLCPP_ERROR(this->get_logger(), "Service call failed: %s", e.what());
        }
    }
};

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TurtleController>();
    rclcpp::spin(node);
    rclcpp::shutdown();

    return 0;
}